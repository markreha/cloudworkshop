#!/bin/bash

# Setup script variables
scheduled=false
logfile="/d/home/site/wwwroot/bin/apache-tomcat-8.5.24/logs/iotWeatherApp.log"
tmplog="/d/home/site/wwwroot/bin/apache-tomcat-8.5.24/logs/temp.log"
logglyTag="iot_logfile_azure_upload"
logglyKey="b79d48aa-0105-4d8b-a5ee-4b9069eed8d3"

# If scheduled then assume scheduler runs to capture previous days logs else for manual assume today
if [ "$scheduled" = true ];
then
	startDate=$(date -j -v-1d +"%Y-%m-%d")" 00:00:00"
	endDate=$(date -j -v-1d +"%Y-%m-%d")" 23:59:59"
else
	startDate=$(date +%Y-%m-%d)" 00:00:00"
	endDate=$(date +%Y-%m-%d)" 23:59:59"
fi

# Extract and send the log file
echo "Extracting and sending log entries between "$startDate" and "$endDate
awk -v sd="$startDate" -v ed="$endDate" -f ./extract.awk $logfile > $tmplog

echo "Sending log files....."
curl -X POST -T $tmplog https://logs-01.loggly.com/bulk/$logglyKey/tag/$logglyTag

# Cleanup
rm $tmplog
